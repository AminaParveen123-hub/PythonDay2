# Everything in python is object
# Topic 1
#What is Programming ?
#Programming is to tell the computer what to do
#like we program the calculator to calculate any number computer do it fastly than humans
#What is python ?
#Python is easy to understand
#It is platform independent
# used in various fields like AI,ML,DS,etc
#It is open source
#It is a high level language
#What is Module?
#Module means we borrow someone else code and use it without knowning their implementation
#for example we use the phone without knowing how it works( its backend functionality )
#Modules of 2 types
# Builtin : We dont need to install them
# External: We have to borrow it from outside world
print("Hello World")
print("100 Days of Code")
print(23*12)
#Print is  a function
# Topic2
# Escape sequences Comments and Print in python
# ctrl+/ is used to comment or uncomment a code base
# "#" is to comment in python
# \n is used to move on new line 
# \" \" is used to put  in form of string
print("Developer without code  is teen dabba\n oh relax")
print("Developer \"without code \" is teen dabba\n oh relax")
# Topic3
# Variables and Data Types
# Vraibles are the containers that store the values
a="Python developer "
print(a)
# Data types
# Text Type:	str
# Numeric Types:	int, float, complex
# Sequence Types:	list, tuple, range
# Mapping Type:	dict
# Set Types:	set, frozenset
# Boolean Type:	bool
# Binary Types:	bytes, bytearray, memoryview
# None Type:	NoneType
a=10
print(a)
print("The type of a is" ,type(a))# By using typeof we can easily find type of the given data for example agy dekho
p="python developer"
print("the type of p is ",type(p))
# han beta lga gai smjh
# Now Topic4
# Ab bnao calculator

